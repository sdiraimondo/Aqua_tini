import com.dalsemi.system.*;
import com.taylec.tini.*;

/**
*
* @version 1.00
* @author Taylec ltd, http://www.taylec.com
*/

public class fb
{
  private final static char INITIAL_BULB = 230;

/**
* Pause
*/
  private static final void pause(int delay_)
  {
    try
    {
      Thread.sleep(delay_);
    }
    catch (InterruptedException e_)
    {
    }
  }

  public static void main(String[] args_)
  {
    try
    {
      Interrupt interrupt = new Interrupt();

      DataPort ldr = new DataPort(0x380001);
      DataPort light = new DataPort(0x380001);

      char current_bulb = INITIAL_BULB;
      if (args_.length > 0)
      {
        try
        {
          Integer ival = new Integer(args_[0]);
          current_bulb = (char) ival.intValue();
        }
        catch (NumberFormatException err_)
        {
          System.err.println(err_);
        }
      }
      light.write(current_bulb);
      pause(500);

      System.out.println("Checking ambient light");
      final int ambient_light = ldr.read();

      while (interrupt.getNumEvents()==0)
      {
        //pause(500);
        final int current_light = ldr.read();

        //System.out.print("Target = ");
        //System.out.print(ambient_light);
        //System.out.print(", Current = ");
        //System.out.print(current_light);
        //System.out.print(", delta = ");
        //System.out.print(ambient_light-current_light);
        //System.out.print(", current_bulb = ");
        //System.out.print((int)current_bulb);
        //System.out.println();

        if (current_light == ambient_light)
        {
        }
        else if (current_light > ambient_light)
        {
          if (current_bulb>0)
          {
            light.write((byte)--current_bulb);
          }
        }
        else
        {
          if (current_bulb<255)
          {
            light.write((byte)++current_bulb);
          }
        }
      }
    }
    catch(IllegalAddressException err_)
    {
    }
  }
}
