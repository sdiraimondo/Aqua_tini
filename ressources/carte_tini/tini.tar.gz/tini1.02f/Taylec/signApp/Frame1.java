//package sign.signApp;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import java.net.*;
import java.io.DataOutputStream;
import com.borland.jbcl.layout.*;

public class Frame1 extends JFrame {
  JMenuBar menuBar1 = new JMenuBar();
  JMenu menuFile = new JMenu();
  JMenuItem menuFileExit = new JMenuItem();
  JMenu menuHelp = new JMenu();
  JMenuItem menuHelpAbout = new JMenuItem();
  JLabel statusBar = new JLabel();
  BorderLayout borderLayout1 = new BorderLayout();
  JLabel jLabel1 = new JLabel();
  JTextField jTextField1 = new JTextField();
  JButton jButton1 = new JButton();
  Box box1;
  Cursor WaitCursor = new Cursor(Cursor.WAIT_CURSOR);
  JTabbedPane jTabbedPane1 = new JTabbedPane();
  JPanel jPanel1 = new JPanel();
  JPanel jPanel2 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  Box box2;
  Box box3;
  Box box4;
  JLabel jLabel3 = new JLabel();
  JTextField jTextField2 = new JTextField();
  JLabel jLabel2 = new JLabel();
  JTextField jTextField3 = new JTextField();

  //Construct the frame
  public Frame1() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try  {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  //Component initialization
  private void jbInit() throws Exception  {
    box1 = Box.createHorizontalBox();
    box2 = Box.createHorizontalBox();
    box3 = Box.createVerticalBox();
    box4 = Box.createVerticalBox();
    this.getContentPane().setLayout(borderLayout1);
    this.setSize(new Dimension(506, 156));
    this.setTitle("LED Sign Demonstration");
    statusBar.setText("Ready");
    menuFile.setMnemonic('F');
    menuFile.setText("File");
    menuFileExit.setMnemonic('E');
    menuFileExit.setText("Exit");
    menuFileExit.addActionListener(new ActionListener()  {

      public void actionPerformed(ActionEvent e) {
        fileExit_actionPerformed(e);
      }
    });
    menuHelp.setMnemonic('H');
    menuHelp.setText("Help");
    menuHelpAbout.setMnemonic('A');
    menuHelpAbout.setText("About");
    menuHelpAbout.addActionListener(new ActionListener()  {

      public void actionPerformed(ActionEvent e) {
        helpAbout_actionPerformed(e);
      }
    });
    jLabel1.setBorder(BorderFactory.createLoweredBevelBorder());
    jLabel1.setText("Enter text below then press the Submit button to display your message");
    jTextField1.setToolTipText("Type your message here");
    jTextField1.setText("Your message here");
    jTextField1.addActionListener(new java.awt.event.ActionListener() {

      public void actionPerformed(ActionEvent e) {
        jTextField1_actionPerformed(e);
      }
    });
    jButton1.setToolTipText("Press to send your message to the TINI server for display on the " +
    "screen");
    jButton1.setText("Submit");
    jButton1.addActionListener(new java.awt.event.ActionListener() {

      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    jPanel1.setLayout(borderLayout2);
    jLabel3.setText("Hostname : ");
    jTextField2.setText("192.168.0.12");
    jTextField2.setColumns(10);
    jLabel2.setText("Port:");
    jTextField3.setText("8888");
    menuFile.add(menuFileExit);
    menuHelp.add(menuHelpAbout);
    menuBar1.add(menuFile);
    menuBar1.add(menuHelp);
    this.setJMenuBar(menuBar1);
    this.getContentPane().add(statusBar, BorderLayout.SOUTH);
    this.getContentPane().add(jTabbedPane1, BorderLayout.CENTER);
    jTabbedPane1.add(jPanel1, "Message");
    jPanel1.add(box1, BorderLayout.EAST);
    box1.add(jButton1, null);
    jPanel1.add(jLabel1, BorderLayout.NORTH);
    jPanel1.add(jTextField1, BorderLayout.CENTER);
    jTabbedPane1.add(jPanel2, "Configuration");
    jPanel2.add(box2, null);
    box2.add(box3, null);
    box3.add(jLabel3, null);
    box3.add(jLabel2, null);
    box2.add(box4, null);
    box4.add(jTextField2, null);
    box4.add(jTextField3, null);
  }

  //File | Exit action performed
  public void fileExit_actionPerformed(ActionEvent e) {
    System.exit(0);
  }

  //Help | About action performed
  public void helpAbout_actionPerformed(ActionEvent e) {
    Frame1_AboutBox dlg = new Frame1_AboutBox(this);
    Dimension dlgSize = dlg.getPreferredSize();
    Dimension frmSize = getSize();
    Point loc = getLocation();
    dlg.setLocation((frmSize.width - dlgSize.width) / 2 + loc.x, (frmSize.height - dlgSize.height) / 2 + loc.y);
    dlg.setModal(true);
    dlg.show();
  }

  //Overridden so we can exit on System Close
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if(e.getID() == WindowEvent.WINDOW_CLOSING) {
      fileExit_actionPerformed(null);
    }
  }

  String checkText(String text_)
  {
  final String text = text_;
  if (text.indexOf("fuck")==-1 &&
      text.indexOf("shit")==-1 &&
      text.indexOf("wank")==-1 &&
      text.indexOf("arse")==-1 &&
      text.indexOf("bastard")==-1 &&
      text.indexOf("cock")==-1 &&
//      text.indexOf("bastard")==-1 &&
//      text.indexOf("bastard")==-1 &&
      text.indexOf("cunt")==-1)
  {
    return text_;
  }
  return "*******";
  }

  void jButton1_actionPerformed(ActionEvent e) {
    final Cursor old_cursor = getCursor();
    try
    {
      setCursor(WaitCursor);
      statusBar.setText("Creating Connection...");
      Socket connection = new Socket(jTextField2.getText(), Integer.parseInt(jTextField3.getText()));
      DataOutputStream dos = new DataOutputStream(connection.getOutputStream());
      statusBar.setText("Sending...");
      final String sent = checkText(jTextField1.getText());
      dos.writeUTF(sent);
      dos.flush();
      dos.close();
      connection.close();
      try { Thread.sleep(1000); } catch (InterruptedException err_){}
      jTextField1.setText(sent);
      jTextField1.selectAll();
      jTextField1.grabFocus();
      statusBar.setText("Ready");
    }
    catch (Exception err_)
    {
      System.err.println(err_);
      statusBar.setText(err_.toString());
    }
    finally
    {
      setCursor(old_cursor);
    }
  }

  void jTextField1_actionPerformed(ActionEvent e) {
    jButton1_actionPerformed(e);
  }
}
