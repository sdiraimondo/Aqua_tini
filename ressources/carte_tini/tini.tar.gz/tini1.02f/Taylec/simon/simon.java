import com.dalsemi.system.*;
import java.lang.*;
import java.util.*;
import java.io.*;
import com.taylec.tini.*;
import com.dalsemi.system.TINIOS;
import com.dalsemi.comm.*;

import com.dalsemi.onewire.*;
import com.dalsemi.onewire.adapter.*;
import com.dalsemi.onewire.container.OneWireContainer12;
import java.util.Enumeration;
/**
* Board Test Routine
*
* @version 1.02
* @author Taylec ltd
*/


public class simon
{
/**
* Pause
*/
  public static final void pause(int delay_)
  {
    try
    {
      Thread.sleep(delay_);
    }
    catch (InterruptedException e_)
    {
    }
  }

  final class blight
  {
    private OneWireContainer12 Device = null;
    private byte State[];
    public blight(OneWireContainer12 device_) throws OneWireException
    {
      Device = device_;
      State = Device.readDevice();
      //System.out.println("blight");
      //System.out.println(Device.getAddressAsString() + '\t' +
      //                   Device.getName() + '\t' +
      //                   Device.getAlternateNames() + '\t' +
      //                   Device.getDescription());
    }

    public final void flash(int delay_) throws OneWireException
    {
      Device.setLatchState(0, true, false, State);
      Device.writeDevice(State);
      pause(delay_);
      Device.setLatchState(0, false, false, State);
      Device.writeDevice(State);
    }
    public final void on() throws OneWireException
    {
      Device.setLatchState(0, true, false, State);
      Device.writeDevice(State);
    }

    public final void off() throws OneWireException
    {
      Device.setLatchState(0, false, false, State);
      Device.writeDevice(State);
    }
    public final void follow() throws OneWireException
    {
      Device.setLatchState(0, true, false, State);
      Device.writeDevice(State);
      while (isPressed());
      Device.setLatchState(0, false, false, State);
      Device.writeDevice(State);
    }

    public final boolean isPressed() throws OneWireException
    {
      final byte state[] = Device.readDevice();
      //System.out.println('.');
      return !Device.getLevel(1, state);
    }
  }
/*---------------------------------------------------------------------------
 * Copyright (C) 1998 Dallas Semiconductor Corporation, All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY,  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL DALLAS SEMICONDUCTOR BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Dallas Semiconductor
 * shall not be used except as stated in the Dallas Semiconductor
 * Branding Policy.
 *---------------------------------------------------------------------------
 */
  private blight[] BLights;

  public simon()
  {
    try
    {
      com.dalsemi.system.TINIOS.enableSerialPort1(false);
      System.out.println("OneWire Tester");

      System.out.println("Default Adapter: " +
                         OneWireAccessProvider.getProperty("onewire.adapter.default"));
      System.out.println("Default Port: " +
                         OneWireAccessProvider.getProperty("onewire.port.default"));

      System.out.println();
      // get the default adapter
      DSPortAdapter adapter = OneWireAccessProvider.getDefaultAdapter();
      adapter.selectPort(OneWireAccessProvider.getProperty("onewire.port.default"));
      adapter.beginExclusive(true);

      // clear any previous search restrictions
      adapter.setSearchAllDevices();
      adapter.targetAllFamilies();
      adapter.targetFamily(0x12);
      adapter.setSpeed(adapter.SPEED_REGULAR);

      // enumerate through all the 1-Wire devices found
      int index = 0;
      for (Enumeration owd_enum = adapter.getAllDeviceContainers();
           owd_enum.hasMoreElements();
           ++index, owd_enum.nextElement())
      {
      }

      BLights = new blight[index];
      index = 0;
      for (Enumeration owd_enum = adapter.getAllDeviceContainers();
           owd_enum.hasMoreElements();
           ++index)
      {
        BLights[index] = new blight((OneWireContainer12) owd_enum.nextElement());
      }

      // end exclusive use of adapter
      adapter.endExclusive();

      // free port used by adapter
      adapter.freePort();
    }
    catch (Exception e)
    {
      System.err.print("Execption caught: ");
      System.err.println(e);
    }
  }

  void play(int routine_length_) throws OneWireException
  {
    java.util.Random rgen = new java.util.Random();
    System.out.println("playing");
    int delay = 1000;
    final int routine_length = routine_length_; //5;

    byte[] memory = new byte[routine_length];
    for (int routine=0; routine!=routine_length; ++routine)
    {
      memory[routine] = (byte) (java.lang.Math.abs(rgen.nextInt())%BLights.length);
      System.out.println(memory[routine]);
      BLights[memory[routine]].flash(1000);
    }

    for (int routine=0; routine!=routine_length; ++routine)
    {
      if (getResponse(0) == memory[routine])
      {
        BLights[memory[routine]].follow();
      }
      else
      {
        System.out.println("Failure");
        for (int i=0; i!=5; ++i)
        {
          BLights[memory[routine]].flash(100);
        }
        return;
      }
    }

    System.out.println("Success!");
    for (int i=0; i!=10; ++i)
    {
      for (int blight=0; blight!=BLights.length; ++blight)
      {
        BLights[blight].flash(1);
      }
    }
  }

  byte getResponse(int timeout_) throws OneWireException
  {
    //com.dalsemi.system.Clock clock = new com.dalsemi.system.Clock();
    //long current_time = clock.getTickCount();
    while (true)
    {
      for (int blight=0; blight!=BLights.length; ++blight)
      {
        if (BLights[blight].isPressed())
        {
          return (byte)blight;
        }
      }
    }
  }
/**
*
*/
  static void main(String[] args_)
  {
    try
    {
      simon Simon = new simon();
      Simon.play(Integer.parseInt(args_[0]));
    }
    catch (Exception err_)
    {
      System.err.println(err_);
    }
  }

}

