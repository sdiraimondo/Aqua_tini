import com.dalsemi.system.*;
import java.lang.*;
import java.util.*;
import java.io.*;
import com.taylec.tini.*;
import com.dalsemi.system.TINIOS;
import com.dalsemi.comm.*;

import com.dalsemi.onewire.OneWireAccessProvider;
import com.dalsemi.onewire.adapter.*;
import com.dalsemi.onewire.container.OneWireContainer;
import java.util.Enumeration;
/**
* Board Test Routine
*
* @version $State: Exp $
* @author Taylec ltd
*/

/**
*
*/
class cantransmit
{
    /* 125Kbit/s with crystal of 18.432MHz */
    static final int CAN_DIVISOR = 7;
    static final int CAN_TSEG1 = 13;
    static final int CAN_TSEG2 = 7;
    static final int CAN_SJW = 1;
    static final byte CANBUSNUM = CanBus.CANBUS0;
//    static final byte CANBUSNUM = CanBus.CANBUS1;

    static void doTest(PrintStream os_) throws Exception
    {
        CanBus a = new CanBus(CANBUSNUM);
        try
        {
          a.setBaudRatePrescaler(CAN_DIVISOR);
          a.setTSEG1(CAN_TSEG1);
          a.setTSEG2(CAN_TSEG2);
          a.setSynchronizationJumpWidth(CAN_SJW);

          // Now, we tell the CAN Controller to jump on the bus.
          a.enableController();

          // Set message center one to transmit.  This allows any outgoing messages
          // to use this register.
          a.setMessageCenterTXMode(1);

          byte[] temp = new byte[8];
          os_.println("Continous send");

          temp[0] = (byte)0xAA;
          temp[1] = 0x55;
          int count = 0;
          while (count<10)
          {
              temp[2] = (byte)(count&0xFF);
              temp[3] = (byte)((count >> 8)&0xFF);

              // Send a frame using extended (29 bit) ID, block until frame is ACKed
//            a.sendDataFrame(0x55F6575C, true, temp);

            // Send a frame using standard (11 bit) ID, block until frame is ACKed
              a.sendDataFrame(0x55F6575C, false, temp);

              if ((count % 10) == 0)
              {
                 Debug.hexDump(count);
              }
              os_.println(count);
              count++;
               try { Thread.sleep(200); } catch(Exception err_){}
            }
        }
        finally
        {
          a.close();
        }
//        os.println("After close()");
    }
}

  class serialThread extends Thread
  {
    private SerialManip Serial;
    private PrintStream os;
    public serialThread(PrintStream os_, SerialManip serial_)
    {
      Serial = serial_;
      os = os_;
    }

    public void run()
    {
      try
      {
        DataOutputStream dos =Serial.getDataOutputStream();
        DataInputStream dis = Serial.getDataInputStream();
        dos.writeChars("\r\nStarting echo\r\n");
        dos.flush();
        while (true)
        {
          dos.writeChars("(");
          dos.write(dis.read());
          dos.writeChars(")\r\n");
          dos.flush();
        }
      }
      catch (IOException err_)
      {
        os.println(err_.toString());
      }
    }
  }

public class test
{
  static InputStream is  = System.in;
  static PrintStream os = System.out;
  static PrintStream es = System.err;

/**
* Pause
*/
  private static final void pause(int delay_)
  {
    try
    {
      Thread.sleep(delay_);
    }
    catch (InterruptedException e_)
    {
    }
  }

/**
*
*/
  public static void testLED(Interrupt interrupt_)
  {
    try
    {
      os.println("LED Tester");
      LEDManip manip = new LEDManip();
      manip.add(LEDManip.R2);
      pause(500);
      manip.add(LEDManip.R3);
      pause(500);
      manip.add(LEDManip.Y1);
      pause(500);
      manip.add(LEDManip.Y2);
      pause(500);
      manip.add(LEDManip.Y3);
      pause(500);
      manip.add(LEDManip.Y4);
      pause(500);
      manip.add(LEDManip.G2);
      pause(500);
      manip.add(LEDManip.G3);
      pause(500);
      manip.subtract(LEDManip.Outer);

      while(true)
      {
        manip.flip(LEDManip.Outer);
        //pause(200);
        manip.flip(LEDManip.Inner);
        pause(200);
        if (interrupt_.getNumEvents()>0)
        {
          return;
        }
      }
    }
    catch (IllegalAddressException err_)
    {
      os.println(err_.toString());
    }
  }
/**
*
*/
  public static void testInterrupt(Interrupt interrupt_)
  {
    while(true)
    {
      if (interrupt_.getNumEvents()>3)
      {
        return;
      }
    pause(100);
    }
  }
/**
*
*/
  public static void testLCD(Interrupt interrupt_)
  {
    try
    {
      os.println("LCD Tester");
      LCDManipFormat manip = new LCDManipFormat();
      //manip.clear();

      manip.out.println("Hello World");
      manip.out.print("next");
      manip.out.flush();
      for (int i=0; i!=5; ++i)
      {
        manip.out.print(i);
        manip.out.flush();
        pause(100);
        manip.out.println();
        if (interrupt_.getNumEvents()>0)
        {
          return;
        }
      }
      //DateFormat df=DateFormat.getDateInstance(DateFormat.SHORT);
      Date last_date = new Date(0);
      while(interrupt_.NumEvents==0)
      {
        final Date next_date = new Date();
        if (last_date != next_date)
        {
          manip.home();
          //manip.out.print(df.format(new java.util.Date()));
          manip.out.print(new java.util.Date());
          manip.out.flush();
          last_date=next_date;
        }
        else
        {
//          pause(10);
        }
      }
    }
    catch (IllegalAddressException err_)
    {
      os.println(err_.toString());
    }
  }
/**
*
*/
  public static void testADC(Interrupt interrupt_)
  {
    try
    {
      os.println("ADC Tester");
      ADCManip adc=new ADCManip();
      while (interrupt_.getNumEvents()==0)
      {
        os.println(adc.readLinearized());
        pause(500);
      }
    }
    catch (IllegalAddressException err_)
    {
      os.println(err_.toString());
    }
  }
/**
*
*/
  public static void testDAC(Interrupt interrupt_)
  {
    try
    {
      os.println("DAC Tester");
      DACManip dac=new DACManip();
      int i=128;
      while (interrupt_.getNumEvents()==0)
      {
        ++i;
        dac.writeDelinearized((double)(i%255));
        //pause(1);
      }

    }
    catch (IllegalAddressException err_)
    {
      os.println(err_.toString());
    }
  }
/**
*
*/
  public static void testDIP(Interrupt interrupt_)
  {
    try
    {
      os.println("DIP Tester");
      DIPManip dip=new DIPManip();
      final int initial_value=dip.read();
      int read_values = 0;
      while (interrupt_.getNumEvents()==0 && read_values!=255)
      {
        final int value=dip.read();
        read_values |= (value^initial_value);
        os.print("current ");
        os.print( ((value&DIPManip.S1) == 0)?0:1);
        os.print( ((value&DIPManip.S2) == 0)?0:1);
        os.print( ((value&DIPManip.S3) == 0)?0:1);
        os.print( ((value&DIPManip.S4) == 0)?0:1);
        os.print( ((value&DIPManip.S5) == 0)?0:1);
        os.print( ((value&DIPManip.S6) == 0)?0:1);
        os.print( ((value&DIPManip.S7) == 0)?0:1);
        os.print( ((value&DIPManip.S8) == 0)?0:1);
        os.print("    changed ");
        os.print( ((read_values&DIPManip.S1) == 0)?0:1);
        os.print( ((read_values&DIPManip.S2) == 0)?0:1);
        os.print( ((read_values&DIPManip.S3) == 0)?0:1);
        os.print( ((read_values&DIPManip.S4) == 0)?0:1);
        os.print( ((read_values&DIPManip.S5) == 0)?0:1);
        os.print( ((read_values&DIPManip.S6) == 0)?0:1);
        os.print( ((read_values&DIPManip.S7) == 0)?0:1);
        os.print( ((read_values&DIPManip.S8) == 0)?0:1);
        os.println();
        pause(500);
      }

    }
    catch (IllegalAddressException err_)
    {
      os.println(err_.toString());
    }
  }
/**
*
*/
  public static void testSerial0(Interrupt interrupt_)
  {
    testSerial(interrupt_, "serial0");
  }
/**
*
*/
  public static void testSerial1(Interrupt interrupt_)
  {
    testSerial(interrupt_, "serial1");
  }
/**
*
*/

  public static void testSerial(Interrupt interrupt_, String serial_port_)
  {
    os.print("Serial Tester on ");
    os.println(serial_port_);

//    Object downserver_command[] = new Object[2];
//    downserver_command[0] = "downserver";
//    downserver_command[1] = "-s";
//    TINIOS.execute(downserver_command,
//                   is,
//                   os,
//                   es,
//                   TINIOS.getCurrentEnvironment());
    BitPort bp = new BitPort(BitPort.Port5Bit7);
    //os.print("BitPort.Port5Bit7 = ");
    os.println(bp.read());
    try
    {
      SerialManip serial=new SerialManip(serial_port_);
      serialThread thread = new serialThread(os, serial);
      thread.start();
      while (interrupt_.getNumEvents()==0)
      {
        pause(500);
      }
      thread.stop();
      thread.join(1000);
    }
    catch (Exception err_)
    {
      es.println(err_);
    }
  }
/**
*
*/
  public static void testI2C(Interrupt interrupt_)
  {
    os.println("I2C Tester");
    os.println("Ensure that the jumpers are set correctly (CRX, CTX, TER)");
    os.println("   Interrupt to continue");
    while (interrupt_.NumEvents==0){ pause(100); }
    interrupt_.reset();

    while (interrupt_.NumEvents==0)
    {
      try
      {
       // Set up I2C driver parameters
        // This uses the default pins P5.0(SCL) and P5.1(SDA)
        I2CPort port = new I2CPort();

        // Set I2C slave we want to talk to.  0x90 in this case.
        port.slaveAddress = (byte)0x48;
        port.setClockDelay((byte)10);
        byte[] b = new byte[5];

        // Send "do temperature convert" command
        b[0] = (byte)0xEE;
        if (port.write(b,0,1) < 0)
        {
          es.println("Fail on conv command");
        }
        else
        {
          pause(500);

          // Send "read temperature" command
          b[0] = (byte)0xAA;
          if (port.write(b,0,1) < 0)
          {
            es.println("Fail on read temp command");
          }
          else
          {
            // Read the two byte temperature value.
            if (port.read(b,0,2) < 0)
            {
              es.println("Fail on read temp");
            }
            else
            {
              // Dump the temperature value as two hex digits
//              for (int j = 0;j < 2;j++)
//                  os.print(Integer.toHexString(b[j] & 0xFF)+" ");
//              os.println();
              os.print((int)b[0]);
              os.print(".");
              os.print((b[1]==0)?"0":"5");
              os.println(" C");
            }
          }
        }
      }
      catch (IllegalAddressException e)
      {
        es.println("Illegal Address on Memory mapped I2C");
      }
    pause(100);
    }
  }


  public static void testCAN(Interrupt interrupt_)
  {
    os.println("CAN Tester");
    os.println("Ensure that the jumpers are set correctly (CRX, CTX, TER)");
    os.println("   Interrupt to continue");
    while (interrupt_.NumEvents==0){ pause(100); }
    interrupt_.reset();

    while (interrupt_.getNumEvents()==0)
    {
      try
      {
        cantransmit.doTest(os);;
      }
      catch(Exception err_)
      {
        os.println("Failed");
        os.println(err_);
        pause(1000);
      }
    }
  }
/**
*
*/
/*---------------------------------------------------------------------------
 * Copyright (C) 1998 Dallas Semiconductor Corporation, All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY,  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL DALLAS SEMICONDUCTOR BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Dallas Semiconductor
 * shall not be used except as stated in the Dallas Semiconductor
 * Branding Policy.
 *---------------------------------------------------------------------------
 */
  public static void testOneWire(Interrupt interrupt_)
  {
    try
    {
      com.dalsemi.system.TINIOS.enableSerialPort1(false);
      os.println("OneWire Tester");

      os.println("Default Adapter: " +
                         OneWireAccessProvider.getProperty("onewire.adapter.default"));
      os.println("Default Port: " +
                         OneWireAccessProvider.getProperty("onewire.port.default"));

      os.println();
      // get the default adapter
      DSPortAdapter adapter = OneWireAccessProvider.getDefaultAdapter();
//      DSPortAdapter adapter = new TINIExternalAdapter();
//      DSPortAdapter adapter = new TINIInternalAdapter();
      for(Enumeration port_name_enum = adapter.getPortNames();
                      port_name_enum.hasMoreElements();
         )
       {
         String port_name = (String)port_name_enum.nextElement();
//         os.println(port_name);
         adapter.selectPort(port_name);

            /* You could check to make sure that it is a valid TINI port here */

        os.println("Adapter: " + adapter.getAdapterName()
                           + ", Port: " + adapter.getPortName());
        os.println();

        // get exclusive use of adapter
        adapter.beginExclusive(true);

        // clear any previous search restrictions
        adapter.setSearchAllDevices();
        adapter.targetAllFamilies();
        adapter.setSpeed(adapter.SPEED_REGULAR);

        // enumerate through all the 1-Wire devices found
        for (Enumeration owd_enum = adapter.getAllDeviceContainers();
             owd_enum.hasMoreElements();
             )
        {
          OneWireContainer owd = ( OneWireContainer ) owd_enum.nextElement();

          os.println(owd.getAddressAsString() + '\t' +
                             owd.getName() + '\t' +
                             owd.getAlternateNames() + '\t' +
                             owd.getDescription());
        }

        // end exclusive use of adapter
        adapter.endExclusive();

        // free port used by adapter
        adapter.freePort();
      }
    }
    catch (Exception e)
    {
      es.print("Execption caught: ");
      es.println(e);
    }
    com.dalsemi.system.TINIOS.enableSerialPort1(true);
  }
  public static void testRelay(Interrupt interrupt_)
  {
    try
    {
      os.println("Relay Tester");
      RelayManip relay=new RelayManip();
      DigitalInputManip dip = new DigitalInputManip();

      os.print("R0 " + (dip.test(RelayManip.R0)?"1":"0"));
      relay.add(RelayManip.R0);
      pause(500);
      os.println(dip.test(RelayManip.R0)?"1":"0");
      os.print("R1 " + (dip.test(RelayManip.R1)?"1":"0"));
      relay.add(RelayManip.R1);
      pause(500);
      os.println(dip.test(RelayManip.R1)?"1":"0");
      os.print("R2 " + (dip.test(RelayManip.R2)?"1":"0"));
      relay.add(RelayManip.R2);
      pause(500);
      os.println(dip.test(RelayManip.R2)?"1":"0");
      os.print("R3 " + (dip.test(RelayManip.R3)?"1":"0"));
      relay.add(RelayManip.R3);
      pause(500);
      os.println(dip.test(RelayManip.R3)?"1":"0");
      os.print("R4 " + (dip.test(RelayManip.R4)?"1":"0"));
      relay.add(RelayManip.R4);
      pause(500);
      os.println(dip.test(RelayManip.R4)?"1":"0");
      os.print("R5 " + (dip.test(RelayManip.R5)?"1":"0"));
      relay.add(RelayManip.R5);
      pause(500);
      os.println(dip.test(RelayManip.R5)?"1":"0");
      os.print("R6 " + (dip.test(RelayManip.R6)?"1":"0"));
      relay.add(RelayManip.R6);
      pause(500);
      os.println(dip.test(RelayManip.R6)?"1":"0");
      os.print("R7 " + (dip.test(RelayManip.R7)?"1":"0"));
      relay.add(RelayManip.R7);
      pause(500);
      os.println(dip.test(RelayManip.R7)?"1":"0");

      relay.flip(RelayManip.Left);
      while(true)
      {
        relay.flip(RelayManip.All);
        pause(200);
        relay.flip(RelayManip.All);
        pause(200);
        if (interrupt_.getNumEvents()>0)
        {
          return;
        }
      }
    }
    catch (IllegalAddressException err_)
    {
      os.println(err_.toString());
    }
  }
  public static void testPIO(Interrupt interrupt_)
  {
    try
    {
      os.println("Programmable IO Tester");
      ProgramIOManip pio=new ProgramIOManip();
      pio.setControl(pio.all_out|pio.all_basic);
      while (interrupt_.getNumEvents()==0)
      {
        os.println("hi");
        pio.writePortA(0xFF);
        pio.writePortB(0xFF);
        pio.writePortC(0xFF);
        pause(2000);
        os.println("lo");
        pio.writePortA(0x00);
        pio.writePortB(0x00);
        pio.writePortC(0x00);
        pause(2000);
      }
    }
    catch (IllegalAddressException err_)
    {
      os.println(err_.toString());
    }
  }/**
*
*/
  static void main(String[] args)
  {
    new test(args);
  }

  public test(InputStream in, PrintStream out, PrintStream err, String[] args)
  {
    is = in;
    os = out;
    es = err;
    doTest(args);
  }

  public test(String[] args)
  {
    doTest(args);
  }

  public test()
  {
    doTest(new String[0]);
  }

  static void doTest(String[] args)
  {
    Interrupt interrupt = new Interrupt();
    if (args.length==0)
    {
      os.println("Starting Full System Test");
      testLED(interrupt);
      interrupt.reset();
      testLCD(interrupt);
      interrupt.reset();
      testDAC(interrupt);
      interrupt.reset();
      testADC(interrupt);
      interrupt.reset();
      testDIP(interrupt);
      interrupt.reset();
      testSerial1(interrupt);
      interrupt.reset();
      testI2C(interrupt);
      interrupt.reset();
      testCAN(interrupt);
      os.println("Finished");
    }
    else
    {
      if (args[0].compareTo("internal")==0)
      {
        os.println("Starting Internal System Test");
        testLED(interrupt);
        interrupt.reset();
        testLCD(interrupt);
        interrupt.reset();
        testDAC(interrupt);
        interrupt.reset();
        testADC(interrupt);
        interrupt.reset();
        testDIP(interrupt);
        os.println("Finished");
      }
      else if (args[0].compareTo("led")==0)
      {
        testLED(interrupt);
      }
      else if (args[0].compareTo("lcd")==0)
      {
        testLCD(interrupt);
      }
      else if (args[0].compareTo("dac")==0)
      {
        testDAC(interrupt);
      }
      else if (args[0].compareTo("adc")==0)
      {
        testADC(interrupt);
      }
      else if (args[0].compareTo("dip")==0)
      {
        testDIP(interrupt);
      }
      else if (args[0].compareTo("serial")==0||args[0].compareTo("serial1")==0)
      {
        testSerial1(interrupt);
      }
      else if (args[0].compareTo("serial0")==0)
      {
        testSerial0(interrupt);
      }
      else if (args[0].compareTo("i2c")==0)
      {
        testI2C(interrupt);
      }
      else if (args[0].compareTo("can")==0)
      {
        testCAN(interrupt);
      }
      else if (args[0].compareTo("onewire")==0)
      {
        testOneWire(interrupt);
      }
      else if (args[0].compareTo("relay")==0)
      {
        testRelay(interrupt);
      }
      else if (args[0].compareTo("pio")==0)
      {
        testPIO(interrupt);
      }
      else
      {
        os.print("Don't know how to test ");
        os.println(args[0]);
        os.println("Choose one of:-");
        os.println("  internal");
        os.println("  led");
        os.println("  lcd");
        os.println("  dac");
        os.println("  adc");
        os.println("  dip");
        os.println("  serial|serial0");
        os.println("  serial1");
        os.println("  i2c");
        os.println("  can");
        os.println("  onewire");
        os.println("  relay");
        os.println("  pio");
      }
    }
    if (interrupt!=null)
      interrupt.stop();
    System.exit(0);
  }

}

