import java.io.*;
import com.taylec.tini.*;
import com.dalsemi.system.*;


public class arm
{
  private static final int MoveArm = 0;
  private static SerialManip Port = new SerialManip("serial1");
  private static DataOutputStream PortStream = Port.getDataOutputStream();
  private static ADCManip LDR;
  private static int Current[] = new int[8];
  private static double Threshold = (float)100.;
  private static boolean Verbose = false;
  private static LCDManipFormat LCD;
   //============================================================================
  //============================================================================
  private static boolean check()
  {
    final double reading = LDR.readLinearized();
    if (Verbose)
    {
      System.out.println("ldr " + reading);
      LCD.clear();
      LCD.out.println("ldr " + reading);
    }
    return (reading<Threshold);
  }
  //============================================================================
  //============================================================================
  private static final void pause(int delay_)
  {
    try
    {
      Thread.sleep(delay_);
    }
    catch (InterruptedException e_)
    {
    }
  }
  //============================================================================
  //============================================================================
  private static int lookUpJoint(String joint_)
  {
    if (joint_.compareTo("base")==0)
      return 1;
    else if (joint_.compareTo("shoulder")==0)
      return 0;
    else if (joint_.compareTo("elbow")==0)
      return 5;
    else if (joint_.compareTo("wrist")==0)
      return 7;
    else if (joint_.compareTo("clamp")==0)
      return 6;
    else
    {
      return -1;
    }
  }
  //============================================================================
  //============================================================================
  private static void cleanLine(StreamTokenizer lis_) throws IOException
  {
    while (true)
    {
      final int ret = lis_.nextToken();
      if (ret==lis_.TT_EOL||ret==lis_.TT_EOF) return;
    }
  }
  //============================================================================
  //============================================================================
  private static void sleepCommand(StreamTokenizer lis_, boolean check_) throws IOException
  {
    if (lis_.TT_NUMBER==lis_.nextToken())
    {
      if (Verbose)
      {
        System.out.println("Sleep " + (int)lis_.nval);
        //LCD.out.println("Sleep " + (int)lis_.nval);
      }
      int period = (int) lis_.nval;
      final int interval = 500;
      pause(period%interval);
      while ((period-=interval)>0)
      {
        if (check_ && check())
          return;
        pause(interval);
      }
    }
    else
    {
      System.err.println("number expected for sleep period, line:" +  lis_.lineno());
    }
  }
  //============================================================================
  //============================================================================
  private static void threshCommand(StreamTokenizer lis_) throws IOException
  {
    if (lis_.TT_NUMBER==lis_.nextToken())
    {
      if (Verbose)
      {
        System.out.println("threshold " + lis_.nval);
        //LCD.out.println("threshold " + lis_.nval);
      }
      Threshold = lis_.nval;
    }
    else
    {
      System.err.println("number expected for threshold, line:" + lis_.lineno());
    }
  }
  //============================================================================
  //============================================================================
  private static void verboseCommand(StreamTokenizer lis_) throws IOException
  {
    if (lis_.TT_WORD==lis_.nextToken())
    {
      if (lis_.sval.compareTo("true")==0)
      {
        Verbose = true;
      }
      else if (lis_.sval.compareTo("false")==0)
      {
        Verbose = true;
      }
      else
      {
        System.err.println("true or false expected for verbosity, line:" + lis_.lineno());
      }

      if (Verbose)
      {
        System.out.println("verbosity " + lis_.sval);
        //LCD.out.println("verbosity " + lis_.sval);
      }
    }
    else
    {
      System.err.println("true or false expected for verbosity, line:" + lis_.lineno());
    }
  }
  //============================================================================
  //============================================================================
  private static void homeCommand(StreamTokenizer lis_, int home_speed_) throws IOException
  {
    //final int home_speed_ = 2;
    moveJoint(1, 127, home_speed_);
    moveJoint(0, 127, home_speed_);
    moveJoint(5, 127, home_speed_);
    moveJoint(6, 127, home_speed_);
    moveJoint(7, 127, home_speed_);
  }
  //============================================================================
  //============================================================================
  private static void moveCommand(StreamTokenizer lis_) throws IOException
  {
    if (lis_.TT_WORD==lis_.nextToken())
    {
      final int joint = lookUpJoint(lis_.sval);
      if (joint==-1)
      {
        System.err.println("Unknown joint \"" + joint + "\", line:" + lis_.lineno());
      }
      else if (lis_.TT_NUMBER==lis_.nextToken())
      {
        final int angle = (int)lis_.nval;
        if (lis_.TT_NUMBER==lis_.nextToken())
        {
          final int speed = (int)lis_.nval;
          moveJoint(joint, angle, speed);
        }
        else
        {
          System.err.println("number expected for speed, line:" + lis_.lineno());
        }
      }
      else
      {
        System.err.println("number expected for angle, line:" + lis_.lineno());
      }
    }
    else
    {
      System.err.println("name expected for joint, line:" + lis_.lineno());
    }
  }
  //============================================================================
  //============================================================================
  private static boolean execute(String file_name_, boolean check_) throws FileNotFoundException, IOException
  {
//    System.out.println(file_name_);
    FileInputStream fis = new FileInputStream(file_name_);
    final boolean retval = execute(fis, check_);
    fis.close();
    return retval;
  }

  //============================================================================
  //============================================================================
  private static boolean execute(InputStream is_, boolean check_) throws IOException
  {
    StreamTokenizer lis = new StreamTokenizer(new InputStreamReader(is_));
    lis.commentChar('#');
    lis.eolIsSignificant(true);
    lis.slashSlashComments(true);
    //lis.parseNumbers();

    while (lis.nextToken()!=lis.TT_EOF)
    {
      if (lis.ttype == lis.TT_WORD)
      {
        if (lis.sval.compareTo("move")==0)
        {
          moveCommand(lis);
        }
        else if (lis.sval.compareTo("sleep")==0)
        {
          sleepCommand(lis, check_);
        }
        else if (lis.sval.compareTo("home")==0)
        {
          homeCommand(lis, 2);
        }
        else if (lis.sval.compareTo("threshold")==0)
        {
          threshCommand(lis);
        }
        else if (lis.sval.compareTo("verbose")==0)
        {
          verboseCommand(lis);
        }
        else
        {
          System.err.println("Unknown command \"" + lis.sval + "\", line:" + lis.lineno());
        }
      cleanLine(lis);
      }
    if (check_ && check())
      return false;
    }
  return true;
  }

  //============================================================================
  //============================================================================
  static void moveJoint(int number_, int angle_, int speed_) throws IOException
  {
    if (Verbose)
    {
      System.out.println("  Move arm " + number_ + " to " + angle_ + " with speed " + speed_);
      //LCD.out.println("  Move arm " + number_ + " to " + angle_ + " with speed " + speed_);
    }

    if (speed_==0)
    {
      PortStream.writeByte(255);
      PortStream.writeByte(number_);
      PortStream.writeByte(angle_);
      PortStream.flush();
    }
    else
    {
      int current = Current[number_];
      final int speed = (current>angle_)?-speed_:speed_;
      current += (angle_-Current[number_])%speed;
      while (current!=angle_)
      {
        PortStream.writeByte(255);
        PortStream.writeByte(number_);
        PortStream.writeByte(current);
        PortStream.flush();
        current+=speed;
      }
    }
    Current[number_] = angle_;
  }

  //============================================================================
  //============================================================================
  static void main(String[] args_)
  {
    System.out.println("Welcome to the TINI Robot Arm demonstrator");
    Interrupt interrupt = new Interrupt();
    try
    {
      homeCommand(null, 0);
      LDR = new ADCManip();
      LCD = new LCDManipFormat();

      if (args_.length == 0)
      {
        while (true)
        {
          while (execute("Play.rap", true));
          execute("TakeCard.rap", false);
        }
      }
      else if (args_[0] == "learn")
      {
        execute(System.in, false);
      }
      else
      {
        execute(args_[0], true);
      }
    }
    catch(IOException err_)
    {
    }
    catch(IllegalAddressException err_)
    {
      System.exit(1);
    }
    catch (Exception err_)
    {
      System.err.println(err_);
    }
  }
}