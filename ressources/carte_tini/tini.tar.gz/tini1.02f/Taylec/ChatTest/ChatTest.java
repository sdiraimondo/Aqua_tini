
import com.taylec.tini.*;
import com.dalsemi.system.TINIOS;
import javax.comm.*;


public class ChatTest
{
  static void main(String[] args_)
  {
    try
    {
      final String phone = "0845";
      final String user = "user";
      final String password = "password";

      Interrupt interrupt = new Interrupt();

      System.out.println("Creating chat");
      Chat chat = new Chat();
      chat.addAbort("NO CARRIER");
      chat.addAbort("BUSY");

      chat.addExpectSend("", "ATZ");
      chat.addExpectSend("OK", "ATD" + phone);
      //chat.addExpectSend("ogin:", user);
      chat.addExpectSend("sername:", user);
      chat.addExpectSend("assword:", password);

      System.out.println("Checking port");
      //SerialManip manip = new SerialManip("serial0");
      TINIOS.enableSerialPort1(true);
      CommPortIdentifier pid = CommPortIdentifier.getPortIdentifier("serial0");
      SerialPort serialport = (SerialPort)pid.open("TINISerialProtocolHandler", 2000);
      serialport.setSerialPortParams(9600, SerialPort.DATABITS_8, SerialPort.STOPBITS_1, SerialPort.PARITY_NONE);
      serialport.setFlowControlMode(SerialPort.FLOWCONTROL_NONE);
      System.out.println("Chatting");
      chat.connect(serialport);

      }
    catch(Exception err_)
    {
      System.err.print("Execption caught: ");
      System.err.println(err_);
    }
    System.exit(0);
  }
};