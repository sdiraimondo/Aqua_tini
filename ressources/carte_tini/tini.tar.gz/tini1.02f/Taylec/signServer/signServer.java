//package sign;
import java.net.*;
import java.io.*;

public class signServer extends Thread {

  boolean packFrame = false;
  Sign sign = new Sign("serial0");
  private static final int MsgRepeatTimes=5;
  private static final String cmdSpeed = "\u008d";
  private static final String cmdClear = "\u008c";

  private static final int DelayChunk = 200;

  String Message;

  private void messagePause(String message_, int speed_, int repeat_)
  {
    sign.Write(cmdSpeed + speed_ + cmdClear + Message);
	  try
	  {
      int delay = (speed_*(1000+(message_.length()*sign.mSPerChar)) * repeat_ );
      Thread.sleep(delay%DelayChunk);
      for (int count=delay/DelayChunk; count>0; --count)
      {
        Thread.sleep(DelayChunk);
      }
    }
    catch (InterruptedException e)
    {
    }
  }
  //Construct the application
  public signServer(String message_) throws IOException {
    Message = message_;
  }

  public void run()
  {
    int speed = 2;
    messagePause(Message, speed, MsgRepeatTimes);
    while (true)
    {
      Message = "www.Taylec.com";
      speed = 3;
      messagePause(Message, speed, MsgRepeatTimes);

      Message = (new java.util.Date()).toString();
      System.out.println(Message);
      Message = Message.replace(':', '.') + "                       ";
      messagePause(Message, speed, 1);
    }

    //System.out.println("3");
  }

  //Main method
  static void main(String[] args) {
    System.out.println("Starting Sign Server");
    try { Thread.sleep(10000); } catch (InterruptedException err_) {}
    try
    {
      ServerSocket ssock = new ServerSocket(8888);
      signServer current_message = new signServer("");
      while (true)
      {
        System.out.println("Waiting for connection...");
        //ssock.setSoTimeout();
        Socket sock = ssock.accept();
        System.out.println("killing thread");

        current_message.stop();
        current_message.join();
        current_message = null;

        DataInputStream dis = new DataInputStream(sock.getInputStream());
        final String message = dis.readUTF();
        System.out.println("received " + message);
        dis.close();
        sock.close();

        current_message = new signServer(message);
        current_message.start();
      }
    }
    catch (Exception err_)
    {
      System.err.println(err_);
    }
  }
} 