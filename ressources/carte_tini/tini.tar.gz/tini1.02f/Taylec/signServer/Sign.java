import java.io.*;
import java.util.*;
import javax.comm.*;

/**
* Base class for all Error exceptions
*
* @see Error
* @version $State: Exp $
* @author Taylec ltd, http://www.taylec.com
*/

public class Sign 

{

	String defaultString = "Taylec Ltd - www.taylec.com ";

	private static final byte preambleVal=(byte)0xAA;

	private static final int lengthOfPreamble=8;

	private static final byte start = (byte)0xBB;

	private static final byte end = (byte)0x80;
	
	private static final byte clear = (byte)0x8C;

    private static final int overheadOfProtocal= lengthOfPreamble + 3;

    private static final int padToBlank=11;
	
	public static final int mSPerChar=100;
	
	private int pad=padToBlank;
	
	private boolean autoBlanking=true;

    static Enumeration portList;
    static CommPortIdentifier portId;
    static SerialPort serialPort;
    static OutputStream outputStream;

	

	public Sign (String portName)

	{

		// defaultString=defaultString_;
	
		portList = CommPortIdentifier.getPortIdentifiers();

        while (portList.hasMoreElements()) {
            portId = (CommPortIdentifier) portList.nextElement();
            if (portId.getPortType() == CommPortIdentifier.PORT_SERIAL) {
                 if (portId.getName().equals(portName) )  
				 {
                   try 
				   {
                     serialPort = (SerialPort)
                     portId.open("Sign Writer", 2000);
                   }
				   catch (PortInUseException e) 
				   {
				   }  
				   try 
				   {
                        outputStream = serialPort.getOutputStream();
                   } 
				   catch (IOException e)
				   {
				   }
                   try 
				   {
                     serialPort.setSerialPortParams(2400,
                            SerialPort.DATABITS_8,
                            SerialPort.STOPBITS_1,
                            SerialPort.PARITY_NONE);
                   } 

				   catch (UnsupportedCommOperationException e) 

				   {

				   }

				 }

			}

		}

	}
	
    public void setPad(int padding_)
	{
	  pad=padding_;
	}
	
	public int getPad ()
	{
	  return pad;
	}

    public void setAutoBlank(boolean blank_)
	{
	  autoBlanking=blank_;
	  if (autoBlanking)
	  {
	    pad=padToBlank;
	  }
	  else
	  {
	    pad=0;
	  }
	
	}
	
	public boolean getAutoBlack()
	{
	  return (autoBlanking);
	}

	public void Write(String ToDisplay)

	{
		byte[] toSend= new byte[ (ToDisplay.length() + overheadOfProtocal + pad) ];

	     // should use but only have API1.1 ->java.util.Arrays

		

		int count;

		for (count=0; count < lengthOfPreamble; ++count)

		{

			toSend[count]=preambleVal;

		}

		// now add the start command  

		toSend[count++]=start;
		toSend[count++]=clear;

		

		// now write the string into the array

		for (int i=0; i < ToDisplay.length();++i)

		{
//            System.out.println("char is " + ToDisplay.charAt(i) );
			toSend[count]=(byte)ToDisplay.charAt(i);
			// the space is not the same as the ascii!!
			if (toSend[count] == 0x20)
			{
			  toSend[count]=0x3A;
			}
		    ++count;
		}

		
		// add padding if there is any
		for (int i=0; i < pad;++i)
		{
	       toSend[count]=(byte)0x3A;
		   ++count;
		}

		// now write the delimiter

		

		toSend[count]=end;

		sendString(toSend); 

	}

	

	public void sendString(byte[] toSend_)

	{
 
		
	  // send the byte array down a comms channel

        try
		{
/* 
	     // just for Debug
	      for (int count=0;count < toSend_.length;++count)
		  {
		    System.out.println("Pos=" + count + " Val=" + ((int)toSend_[count] & 0xff) );
		  }
*/	 
 
		   outputStream.write(toSend_);
	     
		}
		catch (IOException e)
		{
		}
	}

}
