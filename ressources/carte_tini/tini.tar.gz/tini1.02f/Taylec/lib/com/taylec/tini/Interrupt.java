package com.taylec.tini;
import com.dalsemi.system.*;
import com.taylec.tini.*;
/**
* Count the number of times that the interrupt button is pressed. After
* a predetermined number of events, actions may be performed in the
* MaxEventAction method.
* @version $State: Exp $
* @author Taylec ltd, http://www.taylec.com
*/
public class Interrupt extends InterruptManip
{

/**
* Construct with default settings.
*/
  public Interrupt()
  {
    super();
  }

/**
* Construct with specified limit.
* @param max_limit_ Number of events seen before alternative
* action is taken. A limit of 0 (zero) means that the action
* will never be called.
*/
  public Interrupt(int max_limit_)
  {
    super();
  }

/**
* Reset the interrupt count to zero
*/
  public final synchronized void reset()
  {
    NumEvents = 0;
  }

/**
* Called whenever the interrupt button is pressed. May call MaxEventAction.
* @param ev_
*/
  public final synchronized void externalInterruptEvent(ExternalInterruptEvent ev_)
  {
    if (++NumEvents == MaxLimit)
    {
      MaxEventAction();
    }
  }

/**
* Called whenever the maximum number of events betwen resets has been seen.
* This is intended to be overridden in derived classes. The default behaviour
* prints a message to the error channel and aborts the process.
*/
  public void MaxEventAction()
  {
    System.err.println("Received MaxLimit interrupts; aborting testing");
    System.exit(-1);;
  }

/**
* Limit for the number of interrupts seen before alternative
* action is taken. Default to 5.
*/
  private int MaxLimit = 5;

/**
* Number of events seen since last reset/construction.
*/
  public int NumEvents = 0;

/**
* Returns NumEvents
*/
  public synchronized int getNumEvents()
  {
    return NumEvents;
  }
}
