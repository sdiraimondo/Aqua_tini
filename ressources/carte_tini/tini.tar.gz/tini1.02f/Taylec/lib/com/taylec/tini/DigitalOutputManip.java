
package com.taylec.tini;
import com.dalsemi.system.*;

/**
* Manipulate an DigitalOutput array
*
* @version $State: Exp $
* @author Taylec ltd, http://www.taylec.com
*/
public class DigitalOutputManip extends com.dalsemi.system.DataPort
{

/**
* Construct with default Dataport address and turn all DigitalOutputs off
* @see com.dalsemi.system.DataPort
*/
  public DigitalOutputManip() throws IllegalAddressException
  {
    super(0x380000);
    clear();
  }

/**
* Construct with a given Dataport address and turn all DigitalOutputs off
* @param address_ Dataport address
* @see com.dalsemi.system.DataPort
*/
  public DigitalOutputManip(int address_) throws IllegalAddressException
  {
    super(address_);
    clear();
  }

/**
* Add the set of DigitalOutputs to the current state
* @param to_add_ Set of DigitalOutputs to be added
*/
  public synchronized void add(int to_add_) throws IllegalAddressException
  {
    state|=to_add_;
    apply();
  }

/**
* Subtract the set of DigitalOutputs from the current state
* @param to_subtract_ Set of DigitalOutputs to subtract
*/
  public synchronized void subtract(int to_subtract_) throws IllegalAddressException
  {
    state&=~to_subtract_;
    apply();
  }

/**
* Flip the state of the set of DigitalOutputs
* @param to_flip_ set of DigitalOutputs to flip
*/
  public synchronized void flip(int to_flip_) throws IllegalAddressException
  {
    state= (state|to_flip_)&(~(state&to_flip_));
    apply();
  }

/**
* Assign the current set of 'on' DigitalOutputs, all others are turned off
* @param state_ Set of 'on' DigitalOutputs
*/
  public synchronized void set(int state_) throws IllegalAddressException
  {
    state = state_;
    apply();
  }

/**
* Retrieve the current state of the DigitalOutputs. This may differ from the
* Actual state if the DigitalOutputs have been manipulated directly.
* @return Current DigitalOutput state
*/
  public int get()
  {
    return state;
  }

/**
* Turn off all DigitalOutputs
*/
  public void clear() throws IllegalAddressException
  {
    set(0);
  }

/**
* Current Internal state
*/
  private int state=0;

/**
* Apply the current state to the DigitalOutputs
*/
  private void apply() throws IllegalAddressException
  {
    write(state);
  }

}