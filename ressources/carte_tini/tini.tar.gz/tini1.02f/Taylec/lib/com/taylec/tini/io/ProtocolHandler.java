package com.taylec.tini.io;
import java.io.*;
/**
*
* The handler for many different protocols
* TCP, 1-Wire, WAP, WDP, WSP,
* HTTP ( through implementation of URLConnection )
* Knows how to establish/ break connections and how to apply headers
* etc to user writes. Strips off headers etc on user reads.
* @version $State: Exp $
* @author Taylec ltd, http://www.taylec.com
*/
public interface  ProtocolHandler
{
    public DataInputStream getDataInputStream();  // allows foramatted Input
    public DataOutputStream getDataOutputStream(); // allows formatted Output
    public int processReads();  // validates and strips off protocol
                                // related detail for this layer
    public int processWrites(); // places headers/CRC etc ontop of user data
                                // pre-transmit

    public int connect();  // How this protocol layer connects to clients
    public Connection accept();   // How this protocol layer serves clients
    public int disconnect();  // How this protocol layer disconnects clients
}