package com.taylec.tini.io;

/**
* @version $State: Exp $
* @author Taylec ltd, http://www.taylec.com
*/
public class HostDetails
{
    private String protocol="";
    private boolean server=true;
    private String host="";
    private int    port=0;
    private String file="";
    private int retries=0;
    private int retryTimeout=1; // ms

    public void setProtocol(String p){ protocol=p;}
    public void setServer(boolean yes){server=yes;}
    public void setHost(String host_){ host=host_;}
    public void setPort(int port_){port=port_;}
    public void setFile(String file_){file = file_;}
    public void setRetries(int retries_){retries=retries_;}
    public void setRetryTimeout(int timeout_){retryTimeout=timeout_;} // ms

    public String getProtocol(){return protocol;}
    public boolean getServer(){ return server;}
    public String getHost(){return host;}
    public int    getPort(){return port;}
    public String getFile(){ return file;}
    public int getRetries(){return retries;}
    public int getRetryTimeout(){return retryTimeout;} // ms


}
