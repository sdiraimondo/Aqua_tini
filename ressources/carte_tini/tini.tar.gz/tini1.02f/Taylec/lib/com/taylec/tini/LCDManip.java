package com.taylec.tini;
import com.dalsemi.system.*;
/**
* Manipulate an LCD character display
*
* @see com.dalsemi.system.DataPort
* @version $State: Exp $
* @author Taylec ltd, http://www.taylec.com
*/
public class LCDManip extends com.dalsemi.system.DataPort
{
/**
* Construct using default Dataport 0x380002
* @see com.dalsemi.system.DataPort
*/
  public LCDManip() throws IllegalAddressException
  {
    super(0x380002);
    initialize();
  }
/**
* Construct using a given Dataport address
* @see com.dalsemi.system.DataPort
* @param address_ DataPort address
*/
  public LCDManip(int address_) throws IllegalAddressException
  {
    super(address_);
    initialize();
  }

/**
* Initialise the display
*/
  public void initialize() throws IllegalAddressException
  {
    //----------------------
	  sendNibble(0x30);
    pause(10);
    sendNibble(0x30);
    pause(10);
    sendNibble(0x30);
	  sendNibble(0x20);

	  sendNibble(0x20);
	  sendNibble(0xC0);

	  sendNibble(0x10);
	  sendNibble(0x80);

	  sendNibble(0x00);
	  sendNibble(0x30);
    //----------------------
	  sendNibble(0x00);
	  sendNibble(0xE0);
    //----------------------
    clear();
  }

  /**
* Clear the screen and return the cursor to the home position
*/
  public void clear()
  {
    send(true, commandClear);
  }

/**
* Return the cursor to the home position
*/
  public void home()
  {
    send(true, commandHome);
  }

/**
* Move the cursor to the given address
* @param address_ Position (address) to move the cursor to
*/
  public void moveDisplay(int address_)
  {
    send(true, commandToDisplay|address_);
  }

/**
* Move the cursor into the CGRAM
* @param address_ Position within CGRAM
*/
  public void moveCGRAM(int address_)
  {
    send(true, commandToCGRAM|address_);
  }

/**
* Send a byte to the display as two nibbles
* @param instruction_ Instruction (true) or Data (false)
* @param data_ Byte to be written
*/
  public synchronized void send(boolean instruction_, int data_)
  {
    try
    {
      int send_data=0;
      if (!instruction_)
      {
        send_data|=commandRSFlag;
      }
      sendNibble(send_data|(data_&0xF0));
      sendNibble(send_data|( (data_&0x0F)<<4));
    }
    catch(IllegalAddressException err_)
    {
    }
  }

/**
* Send a nibble to the display
*/
  private final void sendNibble(int data_) throws IllegalAddressException
  {
    // lock bus to ensure timings?
    //System.out.println(data_);
    write(data_|commandEFlag);
    //pause(1);
    write(data_);
    //pause(5);
  }

/**
* Sleep
*/
  private static final void pause(int delay_)
  {
    try
    {
      Thread.sleep(delay_);
    }
    catch (InterruptedException e_)
    {
    }
  }

  private static final int commandRSFlag = 0x02;
  private static final int commandEFlag = 0x01;

  private static final int commandClear = 0x01;
  private static final int commandHome = 0x02;
  private static final int commandMoveDirection = 0x04;
  private static final int commandCursorDisplay = 0x08;
  private static final int commandMoveCursorDisplay = 0x10;
  private static final int commandToCGRAM = 0x40;
  private static final int commandToDisplay = 0x80;

  private static final int commandSFlag = 0x01;
  private static final int commandIDFlag = 0x02;
  private static final int commandBFlag = 0x01;
  private static final int commandCFlag = 0x02;
  private static final int commandDFlag = 0x04;
  private static final int commandSCFlag = 0x08;
  private static final int commandRLFlag = 0x04;
  private static final int commandDLFlag = 0x10;
  private static final int commandNFlag = 0x08;
  private static final int commandFFlag = 0x04;
  private static final int commandBFFlag = 0x80;
}
