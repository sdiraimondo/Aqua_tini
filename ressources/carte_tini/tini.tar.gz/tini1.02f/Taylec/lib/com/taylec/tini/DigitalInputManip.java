
package com.taylec.tini;
import com.dalsemi.system.*;

/**
* Manipulate an DigitalInput array
*
* @version $State: Exp $
* @author Taylec ltd, http://www.taylec.com
*/
public class DigitalInputManip extends com.dalsemi.system.DataPort
{

/**
* Construct with default Dataport address and turn all DigitalInputs off
* @see com.dalsemi.system.DataPort
*/
  public DigitalInputManip() throws IllegalAddressException
  {
    super(0x380000);
  }

/**
* Construct with a given Dataport address and turn all DigitalInputs off
* @param address_ Dataport address
* @see com.dalsemi.system.DataPort
*/
  public DigitalInputManip(int address_) throws IllegalAddressException
  {
    super(address_);
  }

/**
*
*/
  public boolean test(int value_) throws IllegalAddressException
  {
    return ( (read()&value_) == value_);
  }
}
