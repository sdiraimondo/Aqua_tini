package com.taylec.tini;
import com.dalsemi.system.*;

/**
* Encapsulation of Analogue to digital conversion
* Raw input is provided by the read methods of the base class
* @version $State: Exp $
* @author Taylec ltd, http://www.taylec.com
*/
public class ADCManip extends DataPort
{
/**
* Construct using default Dataport 0x380001
* @see com.dalsemi.system.DataPort
*/
  public ADCManip() throws IllegalAddressException
  {
    super(0x380001);
  }
/**
* Construct using given Dataport address
* @see com.dalsemi.system.DataPort
* @param address_ DataPort address
*/
  public ADCManip(int address_) throws IllegalAddressException
  {
    super(address_);
  }


/**
* Calculates the linearized version of the raw input.
* The default version simply returns a floating point equivalent
* of the integer reading.
* This is intended to be over-ridden in derived classes
* @param value_ Reading to be linearized.
*/
  public double linearize(int value_)
  {
    return (double) value_;
  }

/**
* Calculates the linearized version of an array of raw input.
* The default version uses the linearize(int) method on each
* item in the array. This is slower than a dedicated
* linearization method, but avoids code duplication.
* This is intended to be over-ridden in derived classes
* @param input_ Array of readings to be linearized.
* @param output_ Array of linearized values.
*/
  public void linearize(byte[] input_, double[] output_)
  {
    final int length=input_.length; 
    for (int i=0; i!=length; ++i)
    {
      output_[i] = linearize((int)input_[i]);
    }
  }
/**
* Return a linearized version of the input.
*/
  final public double readLinearized()
  {
    try
    {
      return linearize(read());
    }
    catch (IllegalAddressException err_)
    {
    }
    return 0;
  }

/**
* Return a linearized array version of the input.
* @param values_ Array into which to read the values
*/
  final public void readLinearized(double[] values_)
  {
    try
    {
      byte[] raw = new byte[values_.length];
      read(raw, 0, values_.length);
      linearize(raw, values_);
    }
    catch (IllegalAddressException err_)
    {
    }
  }
}
