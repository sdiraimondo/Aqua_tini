
package com.taylec.tini;
import com.taylec.tini.LCDManip;
import java.io.*;
import com.dalsemi.system.*;

/**
* Manipulate and provide simple formatting for an LCD character display
*
* @see com.taylec.tini.LCDManip
* @version $State: Exp $
* @author Taylec ltd, http://www.taylec.com
*/
public class LCDManipFormat extends OutputStream
{

/**
* Construct using default Dataport 0x380002
* @see com.dalsemi.system.DataPort
*/  public LCDManipFormat() throws IllegalAddressException
  {
    Manipulator = new LCDManip(0x380002);
    clear();
  }
/**
* Construct using a given Dataport
* @see com.dalsemi.system.DataPort
* @param address_ DataPort address
*/
  public LCDManipFormat(int address_) throws IllegalAddressException
  {
    Manipulator = new LCDManip(address_);
    clear();
  }
  public LCDManip Manipulator;

/**
* Write a character to the device
* Satisfies OutputStream abstract method
*
* @param char_ Character to write to the current cursor position
*/
  public void write(int b)
  {
    switch(b)
    {
      case '\n':
        scroll();
        break;
      case '\r':
        break;
      default:
        if (LineHistory[CurrentLine].length()==displayLength)
        {
          scroll();
        }
        LineHistory[CurrentLine].append((char) b);
        Manipulator.send(false, b);
    }
  }

/*
*
*/
  private void scroll()
  {
    if (++CurrentLine==MaxLines)
    {
      for (int line=1; line!= MaxLines+1; line++)
      {
        final int length=LineHistory[line].length();

        Manipulator.moveDisplay(0x40*(line-1));
        for (int i=0; i!=length; ++i)
        {
          Manipulator.send(false, LineHistory[line].charAt(i));
        }
        // Clear out rest of line from previous value
        final int to_clear=LineHistory[line-1].length()-length;
        for (int i=0; i<to_clear; ++i)
        {
          Manipulator.send(false, ' ');
        }
        LineHistory[line-1] = LineHistory[line];
      }
    CurrentLine = MaxLines-1;
    }
  LineHistory[CurrentLine] = new StringBuffer(displayLength);
  Manipulator.moveDisplay(0x40*CurrentLine);
  }
/**
* Clear the screen and return the cursor to the home position
*/
  public void clear()
  {
    Manipulator.clear();
    for (int i=0; i!=MaxLines+1; ++i)
    {
      LineHistory[i] = new StringBuffer(displayLength);
    }
    CurrentLine = 0;
  }

/**
* Return the cursor to the home position
*/
  public void home()
  {
    Manipulator.home();
    CurrentLine = 0;
    LineHistory[CurrentLine].setLength(0);
  }

/**
* Sleep
*/
  private static final void pause(int delay_)
  {
    try
    {
      Thread.sleep(delay_);
    }
    catch (InterruptedException e_)
    {
    }
  }

/**
* Last line written to the display. This supports simple scrolling
* without needing to read the display
*/
  private StringBuffer LineHistory[] = new StringBuffer[MaxLines+1];
  private int CurrentLine = 0;
  private static final int MaxLines = 2;
  private static final int displayLength = 16;

/**
* Data formatting stream
* @see PrintWriter
*/
  public PrintWriter out = new PrintWriter(this, true);
}

