package com.taylec.tini;
import com.dalsemi.system.*;

/**
* Manipulate DIP switches
* Provided for completeness
*
* @version $State: Exp $
* @author Taylec ltd, http://www.taylec.com
*/
public class DIPManip extends DigitalInputManip
{

/**
* Switch 1
*/
  public static final int S1=0x01;

/**
* Switch 2
*/
  public static final int S2=0x02;

/**
* Switch 3
*/
  public static final int S3=0x04;

/**
* Switch 4
*/
  public static final int S4=0x08;

/**
* Switch 5
*/
  public static final int S5=0x10;

/**
* Switch 6
*/
  public static final int S6=0x20;

/**
* Switch 7
*/
  public static final int S7=0x40;

/**
* Switch 8
*/
  public static final int S8=0x80;

  /**
* All Switches
*/
  public static final int S=0xFF;

/**
* Construct with default Dataport 0x380000
* @see com.dalsemi.system.DataPort
*/
  public DIPManip() throws IllegalAddressException
  {
    super(0x380000);
  }
/**
* Construct with a given Dataport address
* @see com.dalsemi.system.DataPort
* @param address_ Dataport address
*/
  public DIPManip(int address_) throws IllegalAddressException
  {
    super(address_);
  }

}