
package com.taylec.tini;
import com.dalsemi.system.*;

/**
* Manipulate an DigitalInput array
*
* @version $State: Exp $
* @author Taylec ltd, http://www.taylec.com
*/
public class ProgramIOManip
{

  public DataPort portA;
  public DataPort portB;
  public DataPort portC;
  public DataPort control_port;

  /**
  * Set group A to basic mode
  * @see #setControl(int)
  */
  public static final int groupA_basic = 0x00;
  /**
  * Set group A to strobe mode
  * @see #setControl(int)
  */
  public static final int groupA_strobe = 0x20;
  /**
  * Set group A to bistrobe mode
  * @see #setControl(int)
  */
  public static final int groupA_bistrobe = 0x40;
  /**
  * Set group B to basic mode
  * @see #setControl(int)
  */
  public static final int groupB_basic = 0x00;
  /**
  * Set group B to strobe mode
  * @see #setControl(int)
  */
  public static final int groupB_strobe = 0x04;
  /**
  * Set both groups to basic (groupA_basic|groupB_basic)
  * @see #setControl(int)
  */
  public static final int all_basic = groupA_basic|groupB_basic;
  /**
  * Set both groups to strobe (groupA_strobe|groupB_strobe)
  * @see #setControl(int)
  */
  public static final int all_strobe = groupA_strobe|groupB_strobe;

  /**
  * Set Port A to input
  * @see #setControl(int)
  */
  public static final int groupA_portA_in = 0x10;
  /**
  * Set Port A to output
  * @see #setControl(int)
  */
  public static final int groupA_portA_out = 0x0;
  /**
  * Set high order nibble of Port C to input
  * @see #setControl(int)
  */
  public static final int groupA_portChigh_in = 0x08;
  /**
  * Set high order nibble of Port C to output
  * @see #setControl(int)
  */
  public static final int groupA_portChigh_out = 0x0;
  /**
  * Set Port B to input
  * @see #setControl(int)
  */
  public static final int groupB_portB_in = 0x02;
  /**
  * Set Port B to output
  * @see #setControl(int)
  */
  public static final int groupB_portB_out = 0x0;
  /**
  * Set low order nibble of Port C to input
  * @see #setControl(int)
  */
  public static final int groupB_portClow_in = 0x01;
  /**
  * Set low order nibble of Port C to output
  */
  public static final int groupB_portClow_out = 0x0;
  /**
  * Set all ports to input
  * @see #setControl(int)
  */
  public static final int all_in = groupA_portA_in|groupA_portChigh_in|groupB_portB_in|groupB_portClow_in;
  /**
  * Set all ports to output
  * @see #setControl(int)
  */
  public static final int all_out = groupA_portA_out|groupA_portChigh_out|groupB_portB_out|groupB_portClow_out;

  public static final int controlword_flag = 0x80;

/**
* Construct with default Dataport address and turn all DigitalInputs off
* @see com.dalsemi.system.DataPort
*/
  public ProgramIOManip() throws IllegalAddressException
  {
    initialise(0x380004);
  }

/**
* Construct with a given Dataport address and turn all DigitalInputs off
* @param address_ Dataport address
* @see com.dalsemi.system.DataPort
*/
  public ProgramIOManip(int address_) throws IllegalAddressException
  {
    initialise(address_);
  }

  private void initialise(int address_) throws IllegalAddressException
  {
    portA = new DataPort(address_+0);
    portB = new DataPort(address_+1);
    portC = new DataPort(address_+2);
    control_port = new DataPort(address_+3);
  }

  /**
  * Send a control byte
  * @param settings_ Control data to send
  */
  public void setControl(int settings_)
  {
    try { control_port.write((byte)(settings_|controlword_flag));
	    System.out.println(settings_|controlword_flag);}
    catch(IllegalAddressException err_){}
  }

  /**
  * Write data to all three ports
  * @param data_ Data to send
  */
  public void write(int data_)
  {
    try
    {
      portA.write((data_>> 0)&0xF);
      portB.write((data_>> 8)&0xF);
      portC.write((data_>>16)&0xF);
    }
    catch(IllegalAddressException err_){}
  }

  /**
  * Write data to port A
  * @param data_ Data to send
  */
  public void writePortA(int data_)
  {
    try { portA.write(data_); System.out.println("A " + data_);}
    catch(IllegalAddressException err_){}
  }
  /**
  * Write data to port B
  * @param data_ Data to send
  */
  public void writePortB(int data_)
  {
    try { portB.write(data_);  System.out.println("B " + data_);}
    catch(IllegalAddressException err_){}
  }
  /**
  * Write data to port C
  * @param data_ Data to send
  */
  public void writePortC(int data_)
  {
    try { portC.write(data_);  System.out.println("C " + data_);}
    catch(IllegalAddressException err_){}
  }

  /**
  * read data from all three ports
  */
  public int read()
  {
    try
    {
      final int b0 = portA.read();
      final int b1 = portB.read();
      final int b2 = portC.read();
      return (b0<<0)|(b1<<8)|(b2<<16);
    }
    catch(IllegalAddressException err_){ return 0; }
  }

  /**
  * Read data from port A
  */
  public int readPortA()
  {
    try { return portA.read(); }
    catch(IllegalAddressException err_){ return 0; }
  }
  /**
  * Read data from port B
  */
  public int readPortB()
  {
    try { return portB.read(); }
    catch(IllegalAddressException err_){ return 0; }
  }
  /**
  * Read data from port C
  */
  public int readPortC()
  {
    try { return portC.read(); }
    catch(IllegalAddressException err_){ return 0; }
  }

}
