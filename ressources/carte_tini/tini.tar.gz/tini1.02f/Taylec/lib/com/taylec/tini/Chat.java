package com.taylec.tini;
//import com.dalsemi.system.*;
import java.io.*;
import java.lang.*;
import java.util.*;
import com.taylec.tini.TINIError;
import javax.comm.SerialPort;

/**
* Unix chat command functionality
* A chat program is built from expect/send pairs. The program reads from the
* serial connection until the 'expect'ted string is found then sends the 'send'
* string and moves on to the next expect/send pair. An empty expect string
* causes the send string to be sent immediately. Lines that match any of the
* abort strings cause an exception to be thrown.
* @version 1.03
* @author Taylec ltd, http://www.taylec.com
*/
public class Chat
{
  class ExpectSend
  {
    public ExpectSend(String expect_, String send_)
    {
      Expect = expect_;
      Send = send_;
    }
    public final String getExpect() { return Expect; }
    public final String getSend()   { return Send; }

    private String Expect;
    private String Send;
  }
  private Vector AbortStrings = new Vector(10);
  private Vector ExpectSendStrings = new Vector(20);

  private DataOutputStream dos;
  private DataInputStream dis;

/**
* Construct with no arguments
*/
  public Chat()
  {
  }

/**
* Read a line in and check for abort commands
* which cause an exception to be thrown.
*/
  private StringBuffer line_buffer = new StringBuffer("\n");
  private final String getLine() throws IOException, TINIError
  {
    if (line_buffer.length()>0&&line_buffer.charAt(line_buffer.length()-1)=='\n')
    {
      line_buffer.setLength(0);
    }

    char next;
    do
    {
      next = (char) dis.readByte();
      line_buffer.append(next);
    } while (next!='\n' && dis.available()>0);

    final String line = line_buffer.toString();

     for (int i=0; i!=AbortStrings.size(); ++i)
    {
      if (line.indexOf((String)AbortStrings.elementAt(i))!=-1)
      {
        throw new TINIError((String)AbortStrings.elementAt(i));
      }
    }
    return line;
  }

/**
* Add a string that will act as an abort
* @param abort_ String to match
*/
  public void addAbort(String abort_)
  {
    AbortStrings.addElement(abort_);
  }

/**
* Add an expect/send pair to the command list
* @param expect_ String to expect
* @param send_ String to send
*/
  public void addExpectSend(String expect_, String send_)
  {
    ExpectSendStrings.addElement(new ExpectSend(expect_, send_));
  }
/**
* Execute an expect send pair
* @param expect_ String to expect
* @param send_ String to send
**/
  private final void expect_send(ExpectSend es_) throws IOException, TINIError
  {
  System.out.println("Expecting [" + es_.getExpect() + "]");
    if (es_.getExpect().length()!=0)
    {
      while (getLine().indexOf(es_.getExpect())==-1){}
    }
  System.out.println("Sending [" + es_.getSend() + "]");
    dos.writeChars(es_.getSend());
  }

/**
* Execute full expect/send program
**/
  private final void doChat()  throws IOException, TINIError
  {
    for (int i=0; i!=ExpectSendStrings.size(); ++i)
    {
      expect_send((ExpectSend)ExpectSendStrings.elementAt(i));
    }
  }

/**
* Connect using the Taylec SerialManip
* @param port_ Serial connection to use
**/
  public final void connect(SerialManip port_) throws IOException, TINIError
  {
    connect(port_.getDataInputStream(), port_.getDataOutputStream());
  }

/**
* Connect using Java SerialPort
* @param port_ Serial connection to use
**/
  public void connect(SerialPort port_) throws IOException, TINIError
  {
    connect(new DataInputStream(port_.getInputStream()),
            new DataOutputStream(port_.getOutputStream()));
  }

  /**
* Connect using direct streams
* @param dis_ Serial input
* @param dos_ Serial output
**/
  public void connect(DataInputStream dis_, DataOutputStream dos_) throws IOException, TINIError
  {
    dis = dis_;
    dos = dos_;
    doChat();
  }

}
