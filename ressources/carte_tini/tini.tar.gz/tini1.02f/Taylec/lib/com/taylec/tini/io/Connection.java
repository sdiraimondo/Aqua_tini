package com.taylec.tini.io;

/**
* Used where server sides accept multiple connections
* @version $State: Exp $
* @author Taylec ltd, http://www.taylec.com
*/
public class Connection
{
  public String name;
  public int    id;
  public HostDetails associatedHost;
}