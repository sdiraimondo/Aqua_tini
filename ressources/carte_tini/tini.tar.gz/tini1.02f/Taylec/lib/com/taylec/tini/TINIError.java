package com.taylec.tini;

/**
* Base class for all Error exceptions
*
* @see Error
* @version $State: Exp $
* @author Taylec ltd, http://www.taylec.com
*/
public class TINIError extends Exception
{
/**
* Construct with given message
* @param msg_ Message
**/
  public TINIError(String msg_)
  {
    super(msg_);
  }
/**
* Construct with no message
**/
  public TINIError()
  {
    super();
  }
}
