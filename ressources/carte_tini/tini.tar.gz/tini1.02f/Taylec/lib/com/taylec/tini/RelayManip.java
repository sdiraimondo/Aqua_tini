
package com.taylec.tini;
import com.dalsemi.system.*;

/**
* Manipulate a Relay array
*
* @version $State: Exp $
* @author Taylec ltd, http://www.taylec.com
*/
public class RelayManip extends DigitalOutputManip
{

/**
* Relay 0
*/
  public static final int R0=0x01;

/**
* Relay 1
*/
  public static final int R1=0x02;

/**
* Relay 2
*/
  public static final int R2=0x04;

/**
* Relay 3
*/
  public static final int R3=0x08;

/**
* Relay 4
*/
  public static final int R4=0x10;

/**
* Relay 5
*/
  public static final int R5=0x20;

/**
* Relay 6
*/
  public static final int R6=0x40;

/**
* Relay 7
*/
  public static final int R7=0x80;


/**
* All LEDs
*/
  public static final int Left=R0+R1+R2+R3;

/**
* All LEDs
*/
  public static final int Right=R4+R5+R6+R7;

/**
* All LEDs
*/
  public static final int All=Left+Right;

/**
* Construct with default Dataport address and turn all LEDs off
* @see com.dalsemi.system.DataPort
*/
  public RelayManip() throws IllegalAddressException
  {
    super(0x380000);
    clear();
  }

/**
* Construct with a given Dataport address and turn all relays off
* @param address_ Dataport address
* @see com.dalsemi.system.DataPort
*/
  public RelayManip(int address_) throws IllegalAddressException
  {
    super(address_);
    clear();
  }
}
