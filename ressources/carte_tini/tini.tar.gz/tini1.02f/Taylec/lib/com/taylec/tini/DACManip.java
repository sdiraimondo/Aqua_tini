package com.taylec.tini;
import com.dalsemi.system.*;

/**
* Encapsulation of Digital to Analogue conversion
* Raw output is provided by the write methods of the base class
* @version $State: Exp $
* @author Taylec ltd, http://www.taylec.com
*/
public class DACManip extends DataPort
{
/**
* Use default dataport 0x380001
* @see com.dalsemi.system.DataPort
*/
  public DACManip() throws IllegalAddressException
  {
    super(0x380001);
  }
/**
* Construct using given Dataport address
* @see com.dalsemi.system.DataPort
* @param address_ DataPort address
*/
  public DACManip(int address_) throws IllegalAddressException
  {
    super(address_);
  }
/**
* Write a delinearised version of the input.
* The default implementation simply converts
* the integer representation of the double
* value limited between 0 and 255.
* This is intended to be over-ridden in derived classes
* @param value_ Value to be converted
*/
  public int delinearize(double value_)
  {
    if (value_ > 255)
    {
      return 255;
    }
    else if (value_ < 0)
    {
      return 0;
    }
    else
    {
      return (int)value_;
    }
  }
/**
* Write a delinearized version of an array of inputs.
* The default version uses the delinearize(double)
* method on each item in the array. This is slower than
* a dedicated array delinearization method, but avoids
* code duplication.
* This is intended to be over-ridden in derived classes
* @param input_ Array of readings to be delinearized.
* @param output_ Array of delinearized values.
*/
  public void delinearize(double[] input_, byte[] output_)
  {
    final int length=input_.length;
    for (int i=0; i!=length; ++i)
    {
      output_[i] = (byte)delinearize(input_[i]);
    }
  }

/**
* Delinearize and output a value
* @param value_ Data to be written
*/
  public final void writeDelinearized(double value_)
  {
    try
    {
      write(delinearize(value_));
    }
    catch (IllegalAddressException err_)
    {
    }
  }
/**
* Delinearize and output an array of values.
* @param values_ Data values to be delinearized and
* and written.
*/
  public final void writeDelinearized(double[] values_)
  {
    try
    {
      byte[] raw = new byte[values_.length];
      delinearize(values_, raw);
      write(raw, 0, values_.length);
    }
    catch (IllegalAddressException err_)
    {
    }
  }


}
