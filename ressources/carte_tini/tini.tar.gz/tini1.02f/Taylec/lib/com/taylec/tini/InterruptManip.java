package com.taylec.tini;
import com.dalsemi.system.*;

/**
* Spawn a new thread that listens for interrupts
* @version $State: Exp $
* @author Taylec ltd, http://www.taylec.com
*/
public class InterruptManip extends Thread implements ExternalInterruptEventListener
{
/**
* Construct and start the thread.
*/
  public InterruptManip()
  {
    start();
  }

/**
* Thread worker routine.
*/
  public void run ()
  {
    try
    {
     (new ExternalInterrupt()).addEventListener(this);
      Thread.currentThread().suspend(); // this thread is gone forever
    }
    catch(Throwable t)
    {
      //System.out.println(t);
    }
  }

/**
* Action to perform when interrupt occurs.
* This is, by default, System.exit() making the interrupt button
* act as a kind of process abort.
* This is intended to be overridden in derived classes.
*/
  public void externalInterruptEvent(ExternalInterruptEvent ev)
  {
	  System.exit(0);
  }
}