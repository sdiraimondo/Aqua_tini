
package com.taylec.tini;
import com.dalsemi.system.*;

/**
* Manipulate an LEDarray
*
* @version $State: Exp $
* @author Taylec ltd, http://www.taylec.com
*/
public class LEDManip extends DigitalOutputManip
{

/**
* Red LED Column 2
*/
  public static final int R2=0x01;

/**
* Red LED Column 3
*/
  public static final int R3=0x02;

/**
* Yellow LED Column 1
*/
  public static final int Y1=0x04;

/**
* Yellow LED Column 2
*/
  public static final int Y2=0x08;

/**
* Yellow LED Column 3
*/
  public static final int Y3=0x10;

/**
* Yellow LED Column 4
*/
  public static final int Y4=0x20;

/**
* Green LED Column 2
*/
  public static final int G2=0x40;

/**
* Greem LED Column 3
*/
  public static final int G3=0x80;

/**
* All Red LEDs
*/
  public static final int R=R2+R3;

/**
* All Yellow LEDs
*/
  public static final int Y=Y1+Y2+Y3+Y4;

/**
* All Green LEDs
*/
  public static final int G=G2+G3;

/**
* All LEDs
*/
  public static final int All=R+G+Y;

/**
* Outer LEDs
*/
  public static final int Outer=R+G+Y1+Y4;

/**
* Inner LEDs
*/
  public static final int Inner=All-Outer;

/**
* Construct with default Dataport address and turn all LEDs off
* @see com.dalsemi.system.DataPort
*/
  public LEDManip() throws IllegalAddressException
  {
    super(0x380000);
    clear();
  }

/**
* Construct with a given Dataport address and turn all LEDs off
* @param address_ Dataport address
* @see com.dalsemi.system.DataPort
*/
  public LEDManip(int address_) throws IllegalAddressException
  {
    super(address_);
    clear();
  }

}