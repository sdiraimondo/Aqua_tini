package com.taylec.tini;
import com.taylec.tini.io.*;
import java.io.*;
import java.util.*;
import javax.comm.*;
import com.dalsemi.system.TINIOS;
/**
* Serial IO
* @version $State: Exp $
* @author Taylec ltd, http://www.taylec.com
**/
public class SerialManip implements ProtocolHandler
{
/**
*
*/
    private InputStream is=null;
/**
*
*/
    private OutputStream os=null;
/**
*
*/
    private DataInputStream dis=null;
/**
*
*/
    private DataOutputStream dos=null;
/**
*
*/
    private SerialPort serialport=null;
/**
*
*/
    private CommPortIdentifier pid=null;

/**
*
* @param portName_ Name of the port
*/
    public  SerialManip(String portName_)
    {
      initialize(portName_);
    }
/**
*
* Equivalent to SerialManip("serial1")
*/
    public  SerialManip()
    {
      initialize("serial1");
    }

/**
*   
* @param portName_ Name of the port
*/
    private void initialize(String portName_)
    {
      try
      {
      //TINIOS.setExternalSerialPortEnable(2,true);
      //TINIOS.enableSerialPort1(); // depracated in 1.02 
      TINIOS.enableSerialPort1(true);
      pid=CommPortIdentifier.getPortIdentifier(portName_);
      //serialport.notifyOnDataAvailable(true);
      //pid=CommPortIdentifier.getPortIdentifier("COM1");
      serialport=(SerialPort)pid.open("TINISerialProtocolHandler", 2000);
      serialport.setSerialPortParams(9600, SerialPort.DATABITS_8, SerialPort.STOPBITS_1, SerialPort.PARITY_NONE);
      serialport.setFlowControlMode(SerialPort.FLOWCONTROL_NONE);

      is=serialport.getInputStream();
      dis = new DataInputStream(is);
      os=serialport.getOutputStream();
      dos = new DataOutputStream(os);
      }
      catch (Exception e)
      {
        System.err.println(e);
      }
    }

/**
*
*/
    public DataInputStream getDataInputStream()
    {
      return dis;
    }

/**
*
*/
    public DataOutputStream getDataOutputStream()
    {
      return dos;
    }

/**
*
*/
    public int processReads()
    {
      // Nothing to strip
      return 0;
    }

/**
*
*/
    public int processWrites()
    {
      // Nothing to add
      return 0;
    }

/**
*
*/
    public int connect()
    {
      try
      {
      // (SerialPort)pid.open("TINISerialProtocolHandler", 2000);
      }
      catch  (Exception e)
      {
        System.err.println(e);
      }

      return 0;
    }

/**
*
*/
    public int disconnect()
    {
      try
      {
      //(SerialPort)pid.close();
      }
      catch (Exception e)
      {
        System.err.println(e);
      }
      return 0;
    }

/**
*
*/
    public Connection accept()
    {
      Connection conn = new Connection();
      return conn;
    }
}
