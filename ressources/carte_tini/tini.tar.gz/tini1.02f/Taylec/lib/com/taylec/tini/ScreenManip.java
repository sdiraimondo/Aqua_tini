package com.taylec.tini;
import com.dalsemi.system.*;
import java.io.*;
import java.lang.*;
import java.util.*;
import com.taylec.tini.ProgramIOManip;

/**

* @version 1.03
* @author Taylec ltd, http://www.taylec.com
*/
public class ScreenManip
{

  public final static int ASCII_OFFSET = 0x20;

  public final static int TEXT_HOME_COMMAND = 0x40;
  public final static int TEXT_AREA_COMMAND = 0x41;
  public final static int GRAPHICS_HOME_COMMAND = 0x42;
  public final static int GRAPHICS_AREA_COMMAND = 0x43;

  public final static int MODE_COMMAND = 0x80;
  public final static int MODE_OR = 0x00;
  public final static int MODE_XOR = 0x01;
  public final static int MODE_AND = 0x02;
  public final static int MODE_TEXT = 0x04;
  public final static int MODE_CG_ROM = 0x00;
  public final static int MODE_CG_RAM = 0x08;

  public final static int DISPLAY_MODE_COMMAND = 0x90;
  public final static int DISPLAY_MODE_BLINK_ON = 0x01;
  public final static int DISPLAY_MODE_BLINK_OFF = 0x00;
  public final static int DISPLAY_MODE_CURSOR_ON = 0x02;
  public final static int DISPLAY_MODE_CURSOR_OFF = 0x00;
  public final static int DISPLAY_MODE_TEXT_ON = 0x04;
  public final static int DISPLAY_MODE_TEXT_OFF = 0x00;
  public final static int DISPLAY_MODE_GRAPHICS_ON = 0x08;
  public final static int DISPLAY_MODE_GRAPHICS_OFF = 0x00;

  public final static int ADDRESS_COMMAND = 0x24;

  public final static int WRITE_INCREMENT_COMMAND = 0xC0;
  public final static int READ_INCREMENT_COMMAND = 0xC1;
  public final static int WRITE_DECREMENT_COMMAND = 0xC2;
  public final static int READ_DECREMENT_COMMAND = 0xC3;
  public final static int WRITE_COMMAND = 0xC4;
  public final static int READ_COMMAND = 0xC5;

  public ScreenManip() throws IllegalAddressException
  {
    initialise(0x380004);
  }

  public ScreenManip(int address_) throws IllegalAddressException
  {
    initialise(address_);
  }

  private void initialise(int address_) throws IllegalAddressException
  {
    PIO = new ProgramIOManip(address_);
    reset();
    mode(MODE_CG_ROM|MODE_OR);
    graphicsHomeAddress(0x0400);
    graphicsAreaSet(0x1E);
    textHomeAddress(0x0000);
    textAreaSet(0x28);
    displayMode(DISPLAY_MODE_TEXT_ON|DISPLAY_MODE_GRAPHICS_ON);
  }

  private void sendData(int data_){}
  private void sendControl(int data_){}
  private byte readData(){return (byte)0;}
  public void reset()
  {
  }

  void execute(int command_, int high_data_, int low_data_)
  {
    sendData(low_data_);
    sendData(high_data_);
    sendControl(command_);
  }

  void execute(int command_, byte low_data_)
  {
    execute(command_, 0, low_data_);
  }

  void execute(int command_, int full_data_)
  {
    execute(command_, (full_data_>>8)&0xFF, full_data_&0xFF);
  }

  public void graphicsHomeAddress(int address_)
  {
    execute(GRAPHICS_HOME_COMMAND, address_);
  }

  public void graphicsAreaSet(int line_length_)
  {
    execute(GRAPHICS_AREA_COMMAND, 0, line_length_);
  }

  public void textHomeAddress(int address_)
  {
    execute(TEXT_HOME_COMMAND, address_);
  }

  public void textAreaSet(int line_length_)
  {
    execute(TEXT_AREA_COMMAND, 0, line_length_);
  }

  public void mode(int mode_)
  {
    sendControl(MODE_COMMAND|mode_);
  }

  public void displayMode(int mode_)
  {
    sendControl(DISPLAY_MODE_COMMAND|mode_);
  }

  public void address(int address_)
  {
    execute(ADDRESS_COMMAND, address_);
  }

  public void setWriteMode(int mode_)
  {
    WriteMode = mode_;
  }

  public void writeRaw(byte char_)
  {
    sendData(char_);
    sendControl(WriteMode);
  }

  public void writeACII(byte char_)
  {
    writeRaw((byte)(char_-ASCII_OFFSET));
  }

  public void setReadMode(int mode_)
  {
    ReadMode = mode_;
  }

  public byte readRaw()
  {
    sendControl(ReadMode);
    return readData();
  }

  public byte readACII()
  {
    return (byte)(readRaw()+ASCII_OFFSET);
  }

  private int WriteMode = WRITE_INCREMENT_COMMAND;
  private int ReadMode = READ_INCREMENT_COMMAND;
  private ProgramIOManip PIO;
}
